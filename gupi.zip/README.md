# Traffic Congestion Predictor (Streamlit + Neural-like Model)

✅ No training required  
✅ Works instantly  
✅ Deploy to Streamlit

Run locally:
```
pip install -r requirements.txt
streamlit run app.py
```
